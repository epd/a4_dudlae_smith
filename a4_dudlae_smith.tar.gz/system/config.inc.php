<?php
/**
 * @file
 * Configuration file.
 */

define("APP_NAME", "Assignment 4");
define("PRELOAD_DIR", __DIR__ . "/../preload/");
define("POSTLOAD_DIR", __DIR__ . "/../postload/");
define("TEMPLATE_DIR", __DIR__ . "/../templates/");
define("TPL_EXTENSION", ".tpl.php");
