<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Installation | <?php echo APP_NAME; ?></title>
 
    <link rel="stylesheet" href="https://raw.github.com/necolas/normalize.css/master/normalize.css">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
    <h1>Installation Complete</h1>
    <p>Go back to the <a href="/">homepage</a></p>
  </body>
</html>
