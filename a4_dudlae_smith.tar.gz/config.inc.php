<?php
/**
 * @file
 * User-level configuration file.
 *
 * NOTE: Replace this file to connect to your own database.
 */

$config = array(
  'db' => '',
  'user' => '',
  'pass' => '',
);
